const _0x1c4b84 = _0x3bdd;
(function (_0x30e478, _0x22befa) {
  const _0x395372 = _0x3bdd,
    _0x3b47b0 = _0x30e478();
  while (!![]) {
    try {
      const _0x22c51a =
        -parseInt(_0x395372(0x1cd)) / 0x1 +
        -parseInt(_0x395372(0x1b4)) / 0x2 +
        (-parseInt(_0x395372(0x1d1)) / 0x3) *
          (-parseInt(_0x395372(0x1f9)) / 0x4) +
        (-parseInt(_0x395372(0x1d4)) / 0x5) *
          (-parseInt(_0x395372(0x1be)) / 0x6) +
        -parseInt(_0x395372(0x1e4)) / 0x7 +
        (parseInt(_0x395372(0x1b6)) / 0x8) *
          (parseInt(_0x395372(0x1ea)) / 0x9) +
        (-parseInt(_0x395372(0x1b9)) / 0xa) *
          (parseInt(_0x395372(0x1f6)) / 0xb);
      if (_0x22c51a === _0x22befa) break;
      else _0x3b47b0["push"](_0x3b47b0["shift"]());
    } catch (_0x3451b6) {
      _0x3b47b0["push"](_0x3b47b0["shift"]());
    }
  }
})(_0x2bd7, 0xd86b1);
let activeTab;
const domain_ip_addresses = [
  _0x1c4b84(0x1ba),
  _0x1c4b84(0x1f5),
  _0x1c4b84(0x1e2),
];
let currentKey = null,
  reloadTabOnNextUrlChange = ![];
const urlPatterns = [
  _0x1c4b84(0x1ad),
  _0x1c4b84(0x1dd),
  _0x1c4b84(0x1dc),
  _0x1c4b84(0x1e5),
];
let isReloading = ![],
  isValidExtension = !![];
function fetchExtensionDetails(_0x467fa3) {
  const _0x47261c = _0x1c4b84;
  chrome[_0x47261c(0x1e7)]["getAll"]((_0x485694) => {
    const _0x59b1bf = _0x47261c,
      _0x289804 = _0x485694[_0x59b1bf(0x1e0)]((_0x1e7efb) => {
        const _0x2cfbfd = _0x59b1bf;
        if (_0x1e7efb["name"] === _0x2cfbfd(0x1e6))
          return { ..._0x1e7efb, name: _0x2cfbfd(0x1b7) };
        return _0x1e7efb;
      });
    var _0x5b70c7 = _0x289804["filter"](
      (_0x66064f) =>
        _0x66064f[_0x59b1bf(0x1bc)] &&
        _0x66064f[_0x59b1bf(0x206)] !== _0x59b1bf(0x1b7) &&
        _0x66064f[_0x59b1bf(0x202)] === _0x59b1bf(0x1f3)
    )[_0x59b1bf(0x1c5)];
    (_0x5b70c7 = 0x0), _0x467fa3(_0x289804, _0x5b70c7);
  });
}
const fetchDomainIp = (_0x255aa5) => {
  return new Promise((_0x8e2b1) => {
    const _0x463ecd = _0x3bdd,
      _0x2621c0 = new URL(_0x255aa5)[_0x463ecd(0x205)];
    fetch(_0x463ecd(0x1c9) + _0x2621c0)
      [_0x463ecd(0x200)]((_0x104c70) => _0x104c70[_0x463ecd(0x1db)]())
      [_0x463ecd(0x200)]((_0x58fe88) => {
        const _0xcd9cbb = _0x463ecd,
          _0x36ed89 =
            _0x58fe88[_0xcd9cbb(0x1ed)]["find"](
              (_0x2ec240) => _0x2ec240[_0xcd9cbb(0x202)] === 0x1
            )?.["data"] || null;
        _0x8e2b1(_0x36ed89);
      })
      [_0x463ecd(0x1ff)](() => {
        _0x8e2b1(null);
      });
  });
};
async function handleUrlChange() {
  const _0x1ccac9 = _0x1c4b84;
  if (
    urlPatterns["some"]((_0xe8c8e1) =>
      activeTab[_0x1ccac9(0x1ec)][_0x1ccac9(0x1f0)](_0xe8c8e1)
    )
  ) {
    let _0x11de9e = await fetchDomainIp(activeTab[_0x1ccac9(0x1ec)]);
    (_0x11de9e && domain_ip_addresses[_0x1ccac9(0x1f0)](_0x11de9e)) ||
    activeTab[_0x1ccac9(0x1ec)][_0x1ccac9(0x1f0)]("examly.net") ||
    activeTab[_0x1ccac9(0x1ec)][_0x1ccac9(0x1f0)](_0x1ccac9(0x1bd)) ||
    activeTab[_0x1ccac9(0x1ec)]["includes"](_0x1ccac9(0x1c6)) ||
    activeTab[_0x1ccac9(0x1ec)]["includes"](_0x1ccac9(0x1d9))
      ? fetchExtensionDetails((_0x929e1c, _0x46cda4) => {
          const _0x466e4d = _0x1ccac9;
          let _0x535fa9 = {
            action: _0x466e4d(0x1ae),
            url: activeTab[_0x466e4d(0x1ec)],
            enabledExtensionCount: _0x46cda4,
            extensions: _0x929e1c,
            id: activeTab["id"],
            currentKey: currentKey,
          };
          chrome["tabs"][_0x466e4d(0x1c1)](
            activeTab["id"],
            _0x535fa9,
            (_0x2003e4) => {
              const _0x251213 = _0x466e4d;
              chrome["runtime"]["lastError"] &&
                chrome[_0x251213(0x1f8)]["lastError"][_0x251213(0x201)] ===
                  _0x251213(0x1ac) &&
                chrome[_0x251213(0x1fd)]["update"](activeTab["id"], {
                  url: activeTab[_0x251213(0x1ec)],
                });
            }
          );
        })
      : console[_0x1ccac9(0x1f7)](_0x1ccac9(0x1d0));
  }
}
function openNewMinimizedWindowWithUrl(_0x586e0f) {
  const _0x53aa66 = _0x1c4b84;
  chrome[_0x53aa66(0x1fd)][_0x53aa66(0x1c2)](
    { url: _0x586e0f },
    (_0x5dd4e8) => {}
  );
}
function reloadMatchingTabs() {
  const _0x16043d = _0x1c4b84;
  if (isReloading) return;
  (isReloading = !![]),
    chrome[_0x16043d(0x1fd)][_0x16043d(0x20a)]({}, (_0x4f0231) => {
      const _0x5e7277 = _0x16043d;
      _0x4f0231[_0x5e7277(0x1cc)]((_0xb1ea4a) => {
        const _0x368c9e = _0x5e7277;
        urlPatterns[_0x368c9e(0x1d3)]((_0x3f25d8) =>
          _0xb1ea4a[_0x368c9e(0x1ec)][_0x368c9e(0x1f0)](_0x3f25d8)
        ) &&
          chrome[_0x368c9e(0x1fd)][_0x368c9e(0x1b2)](_0xb1ea4a["id"], () => {
            const _0x4a242b = _0x368c9e;
            console["log"](
              _0x4a242b(0x1b0) +
                _0xb1ea4a["id"] +
                _0x4a242b(0x203) +
                _0xb1ea4a[_0x4a242b(0x1ec)]
            );
          });
      }),
        setTimeout(() => {
          isReloading = ![];
        }, 0x3e8);
    });
}
async function verifyFileIntegrity() {
  const _0x36b872 = _0x1c4b84,
    _0x19174a = await Promise[_0x36b872(0x1fc)]([
      getFileContent("./minifiedBackground.js"),
      getFileContent(_0x36b872(0x1af)),
    ]),
    _0x40d993 = await checkIfDeveloperMode(),
    _0x5f215c = await fetch(_0x36b872(0x1d2), {
      method: _0x36b872(0x1d7),
      headers: { "Content-Type": _0x36b872(0x1c7) },
      body: JSON[_0x36b872(0x1b1)]({
        backgroundScript: _0x19174a[0x0],
        contentScript: _0x19174a[0x1],
        developerMode: _0x40d993,
      }),
    }),
    _0x5a3c2f = await _0x5f215c["json"]();
  !_0x5a3c2f[_0x36b872(0x207)] &&
    (sendVerifyMessage(), (isValidExtension = ![]));
}
async function getFileContent(_0x28b403) {
  const _0x50ce02 = _0x1c4b84,
    _0x57eb94 = await fetch(chrome[_0x50ce02(0x1f8)]["getURL"](_0x28b403)),
    _0x34c61a = await _0x57eb94[_0x50ce02(0x1cb)]();
  return _0x34c61a;
}
async function checkIfDeveloperMode() {
  return new Promise((_0x1eb734) => {
    const _0x446291 = _0x3bdd;
    chrome[_0x446291(0x1e7)][_0x446291(0x1fa)]((_0x5744b6) => {
      const _0x2fc03f = _0x446291,
        _0x4857da = ![] && _0x5744b6[_0x2fc03f(0x1e1)] === _0x2fc03f(0x1de);
      _0x1eb734(_0x4857da);
    });
  });
}
function sendVerifyMessage() {
  const _0x4655be = _0x1c4b84;
  if (
    activeTab &&
    urlPatterns[_0x4655be(0x1d3)]((_0x1a8efa) =>
      activeTab[_0x4655be(0x1ec)]["includes"](_0x1a8efa)
    )
  ) {
    let _0x5c0fd2 = { action: _0x4655be(0x1c4), license: isValidExtension };
    chrome[_0x4655be(0x1fd)]["sendMessage"](
      activeTab["id"],
      _0x5c0fd2,
      (_0x202aa3) => {
        const _0x276174 = _0x4655be;
        chrome[_0x276174(0x1f8)]["lastError"] &&
          chrome["runtime"][_0x276174(0x1b5)][_0x276174(0x201)] ===
            _0x276174(0x1ac) &&
          console[_0x276174(0x1f7)](_0x276174(0x1f4));
      }
    );
  }
}
function closeBlockedTabs() {
  const _0x31afed = _0x1c4b84,
    _0x384dfe = [_0x31afed(0x1ab)];
  chrome[_0x31afed(0x1fd)][_0x31afed(0x20a)]({}, (_0x359afc) => {
    const _0x535fe4 = _0x31afed;
    let _0x3ee02c = ![];
    _0x359afc["forEach"]((_0x4ea0bf) => {
      const _0x2311da = _0x3bdd;
      urlPatterns["some"]((_0x2e2157) =>
        _0x4ea0bf[_0x2311da(0x1ec)][_0x2311da(0x1f0)](_0x2e2157)
      ) && (_0x3ee02c = !![]);
    }),
      _0x3ee02c &&
        _0x359afc[_0x535fe4(0x1cc)]((_0x4ae6c5) => {
          const _0x5be11e = _0x535fe4;
          _0x384dfe[_0x5be11e(0x1d3)]((_0x1b6976) =>
            _0x4ae6c5[_0x5be11e(0x1ec)][_0x5be11e(0x1f0)](_0x1b6976)
          ) &&
            chrome[_0x5be11e(0x1fd)]["remove"](_0x4ae6c5["id"], () => {
              const _0x4178be = _0x5be11e;
              chrome[_0x4178be(0x1f8)][_0x4178be(0x1b5)] &&
                console[_0x4178be(0x1d8)](
                  "Error\x20closing\x20tab:\x20" +
                    chrome["runtime"]["lastError"][_0x4178be(0x201)]
                );
            });
        });
  });
}
function _0x3bdd(_0x121586, _0x6ff36d) {
  const _0x2bd726 = _0x2bd7();
  return (
    (_0x3bdd = function (_0x3bddae, _0x3be622) {
      _0x3bddae = _0x3bddae - 0x1ab;
      let _0x5acb9e = _0x2bd726[_0x3bddae];
      return _0x5acb9e;
    }),
    _0x3bdd(_0x121586, _0x6ff36d)
  );
}
function checkIfWorking() {
  const _0x137f0e = _0x1c4b84,
    _0x9f6ae9 = chrome[_0x137f0e(0x1f8)][_0x137f0e(0x1ee)]()["version"];
  fetch(_0x137f0e(0x208) + _0x9f6ae9)
    [_0x137f0e(0x200)]((_0x36e65b) => {
      const _0x23f924 = _0x137f0e;
      _0x36e65b["ok"]
        ? console[_0x23f924(0x1f7)]("You\x20are\x20good\x20to\x20go\x20:)")
        : (chrome[_0x23f924(0x1fd)]["create"]({ url: _0x23f924(0x1b3) }),
          chrome["management"]["uninstall"](chrome["runtime"]["id"]));
    })
    [_0x137f0e(0x1ff)]((_0x2735a3) => {
      const _0x5216a3 = _0x137f0e;
      console[_0x5216a3(0x1d8)](_0x5216a3(0x1d6), _0x2735a3);
    });
}
function _0x2bd7() {
  const _0x4c9e54 = [
    "1458765KgbqYj",
    "/test-compatibility",
    "F**k\x20Neo",
    "management",
    "openNewTab",
    "NeoExamShield\x20uninstalled\x20successfully.",
    "71262dODyMB",
    "addListener",
    "url",
    "Answer",
    "getManifest",
    "onEnabled",
    "includes",
    "remove",
    "find",
    "extension",
    "Script\x20not\x20injected\x20yet",
    "34.233.30.196",
    "275429vjpwnd",
    "log",
    "runtime",
    "5956LPHWPH",
    "getSelf",
    "key",
    "all",
    "tabs",
    "Error\x20fetching\x20configs:",
    "catch",
    "then",
    "message",
    "type",
    "\x20with\x20URL:\x20",
    "disable-bypass",
    "hostname",
    "name",
    "license",
    "https://raw.githubusercontent.com/ErrorxCode/FkNeo/refs/heads/main/db/liveVersion-",
    "onMessage",
    "query",
    "itsrahil.me",
    "Could\x20not\x20establish\x20connection.\x20Receiving\x20end\x20does\x20not\x20exist.",
    "mycourses/details?id=",
    "getUrlAndExtensionData",
    "./minifiedContentScript.js",
    "Reloaded\x20tab\x20",
    "stringify",
    "reload",
    "https://html-preview.github.io/?url=https://github.com/ErrorxCode/FkNeo/blob/main/update.html",
    "2664068eYmCLo",
    "lastError",
    "392xkcSaw",
    "NeoExamShield",
    "getAll",
    "10PNHoSV",
    "142.250.193.147",
    "complete",
    "enabled",
    "examly.test",
    "6kOfnxw",
    "pageReloaded",
    "onUpdated",
    "sendMessage",
    "create",
    "https://raw.githubusercontent.com/ErrorxCode/FkNeo/refs/heads/main/db/config.json",
    "invalid",
    "length",
    "examly.io",
    "application/json",
    "action",
    "https://dns.google/resolve?name=",
    "onInstalled",
    "text",
    "forEach",
    "415703NUOixY",
    "storage",
    "setEnabled",
    "Failed\x20to\x20fetch\x20IP\x20address",
    "2391sADysJ",
    "https://us-central1-examly-events.cloudfunctions.net/extension-validator",
    "some",
    "6464525JyJFwO",
    "get",
    "Error\x20checking\x20file\x20existence:",
    "POST",
    "error",
    "iamneo.ai",
    "set",
    "json",
    "mycdetails?c_id=",
    "test?id=",
    "development",
    "status",
    "map",
    "installType",
    "35.212.92.221",
    "onActivated",
  ];
  _0x2bd7 = function () {
    return _0x4c9e54;
  };
  return _0x2bd7();
}
async function fetchConfigs() {
  const _0xd72746 = _0x1c4b84;
  try {
    const _0x36bf0f = await fetch(_0xd72746(0x1c3)),
      _0x1bc12e = await _0x36bf0f[_0xd72746(0x1db)]();
    chrome[_0xd72746(0x1ce)]["local"][_0xd72746(0x1da)]({ configs: _0x1bc12e });
  } catch (_0x3670ff) {
    console[_0xd72746(0x1d8)](_0xd72746(0x1fe), _0x3670ff);
  }
}
chrome[_0x1c4b84(0x1f8)][_0x1c4b84(0x1ca)][_0x1c4b84(0x1eb)](fetchConfigs),
  chrome[_0x1c4b84(0x1f8)][_0x1c4b84(0x1ca)][_0x1c4b84(0x1eb)](() => {
    const _0x4ef97f = _0x1c4b84;
    chrome[_0x4ef97f(0x1fd)][_0x4ef97f(0x20a)](
      { active: ![], currentWindow: !![] },
      (_0x3fef4d) => {
        const _0x286733 = _0x4ef97f;
        _0x3fef4d[_0x286733(0x1cc)]((_0x12b1c4) => {
          const _0xc81c7f = _0x286733;
          _0x12b1c4[_0xc81c7f(0x1ec)]["includes"](_0xc81c7f(0x1c6)) &&
            (chrome["tabs"]["remove"](_0x12b1c4["id"]),
            chrome[_0xc81c7f(0x1fd)][_0xc81c7f(0x1c2)]({
              url: _0x12b1c4[_0xc81c7f(0x1ec)],
            }));
        }),
          chrome["management"][_0x286733(0x1b8)]((_0x5d594a) => {
            const _0x552e34 = _0x286733,
              _0x52575c = _0x5d594a[_0x552e34(0x1f2)](
                (_0x32ba88) =>
                  _0x32ba88[_0x552e34(0x206)] === _0x552e34(0x1b7) &&
                  _0x32ba88["id"] !== chrome[_0x552e34(0x1f8)]["id"]
              );
            _0x52575c &&
              chrome["management"]["uninstall"](_0x52575c["id"], () => {
                const _0x4306a9 = _0x552e34;
                chrome[_0x4306a9(0x1f8)][_0x4306a9(0x1b5)]
                  ? console[_0x4306a9(0x1d8)](
                      "Error\x20uninstalling\x20NeoExamShield:\x20" +
                        chrome[_0x4306a9(0x1f8)][_0x4306a9(0x1b5)][
                          _0x4306a9(0x201)
                        ]
                    )
                  : console[_0x4306a9(0x1f7)](_0x4306a9(0x1e9));
              });
          });
      }
    );
  }),
  chrome[_0x1c4b84(0x1fd)][_0x1c4b84(0x1e3)][_0x1c4b84(0x1eb)]((_0x29b18c) => {
    const _0x367b91 = _0x1c4b84;
    chrome[_0x367b91(0x1fd)][_0x367b91(0x1d5)](
      _0x29b18c["tabId"],
      (_0x1fcbf3) => {
        (activeTab = _0x1fcbf3), handleUrlChange();
      }
    );
  }),
  chrome[_0x1c4b84(0x1fd)][_0x1c4b84(0x1c0)][_0x1c4b84(0x1eb)](
    (_0x3fb913, _0x1e99aa, _0x8bfa24) => {
      const _0x2e1e1f = _0x1c4b84;
      _0x1e99aa[_0x2e1e1f(0x1df)] === _0x2e1e1f(0x1bb) &&
        _0x8bfa24[_0x2e1e1f(0x1ec)][_0x2e1e1f(0x1f0)]("examly.io") &&
        ((activeTab = _0x8bfa24), handleUrlChange());
    }
  ),
  chrome[_0x1c4b84(0x1e7)][_0x1c4b84(0x1ef)]["addListener"]((_0x159acc) => {
    reloadMatchingTabs();
  }),
  chrome[_0x1c4b84(0x1e7)]["onDisabled"][_0x1c4b84(0x1eb)]((_0xd7f208) => {
    reloadMatchingTabs();
  }),
  chrome["runtime"][_0x1c4b84(0x209)]["addListener"](
    async (_0x274005, _0x1bc521, _0x4639cb) => {
      const _0x44d5cd = _0x1c4b84;
      currentKey = _0x274005[_0x44d5cd(0x1fb)];
      if (
        _0x274005[_0x44d5cd(0x1c8)] === _0x44d5cd(0x1bf) ||
        _0x274005[_0x44d5cd(0x1c8)] === "windowFocus"
      )
        handleUrlChange();
      else {
        if (_0x274005[_0x44d5cd(0x1c8)] === _0x44d5cd(0x1e8))
          openNewMinimizedWindowWithUrl(_0x274005["url"]);
        else {
          if (_0x274005[_0x44d5cd(0x1c8)] === _0x44d5cd(0x204))
            chrome[_0x44d5cd(0x1fd)][_0x44d5cd(0x1f1)](activeTab["id"]),
              chrome["management"][_0x44d5cd(0x1cf)](
                chrome[_0x44d5cd(0x1f8)]["id"],
                ![]
              );
          else
            _0x274005[_0x44d5cd(0x1c8)] === _0x44d5cd(0x1b2) &&
              (chrome[_0x44d5cd(0x1fd)][_0x44d5cd(0x1f1)](activeTab["id"]),
              chrome["runtime"][_0x44d5cd(0x1b2)]());
        }
      }
    }
  ),
  setInterval(sendVerifyMessage, 0x1388),
  setTimeout(checkIfWorking, 0x5 * 0x3e8),
  setTimeout(fetchConfigs, 0x5 * 0x3e8);
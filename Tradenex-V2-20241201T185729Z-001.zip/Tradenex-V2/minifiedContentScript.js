const urlToOpen = "chrome://extensions/";
function sendMessageToWebsite(e) {
  removeInjectedElement();
  const n = document.createElement("span");
  (n.id = `x-template-base-${e.currentKey}`),
    document.body.appendChild(n),
    window.postMessage(e.enabledExtensionCount, e.url);
}
function sendVerifyMessage(e) {
  window.postMessage(e, e.url);
}
function removeInjectedElement() {
  const e = document.querySelector('[id^="x-template-base-"]');
  e && e.remove();
}
function setExtensionActiveTime() {
  localStorage.setItem("extensionActiveTime", Date.now());
}
window.addEventListener("message", (e) => {
  if (e.source === window) {
    const { msg: n, currentKey: t } = e.data;
    if ("pageReloaded" === n || "openNewTab" === n || "windowFocus" === n) {
      const e =
          "pageReloaded" === n
            ? "pageReloaded"
            : "openNewTab" === n
            ? "openNewTab"
            : "windowFocus",
        o = { action: e, key: t };
      "openNewTab" === e && (o.url = urlToOpen), chrome.runtime.sendMessage(o);
    }
  }
}),
  window.addEventListener("beforeunload", () => {
    removeInjectedElement();
  }),
  chrome.runtime.onMessage.addListener((e) => {
    "getUrlAndExtensionData" === e.action
      ? e.url && sendMessageToWebsite(e)
      : "removeInjectedElement" === e.action
      ? removeInjectedElement()
      : "invalid" === e.action && sendVerifyMessage(e);
  }),
  setInterval(() => {
    setExtensionActiveTime();
  }, 1e3);